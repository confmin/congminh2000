<?php
include('auth.php');
include('Connect.php');
include('header.php');
?>
      <div class="Phan2Phai">
          <h4> Hệ Thống Quản Lý Bán LapTop Hoàng Nam</h4>
          
          <div class="BonHinh">
            <div class="BonHinh1">
              <h5>76 Tổng số tin tức</h5>
              <p>more info</p>
            </div>
            <div class="BonHinh2">
              <h5>77 Tổng số sản phẩm</h5>
              <p>more info</p>
            </div>
            <div class="BonHinh3">
              <h5>78 Tổng số lượt truy cập</h5>
              <p>more info</p>
            </div>
            <div class="BonHinh4">
              <h5>79 Tổng số liên hệ</h5>
              <p>more info</p>
            </div>
          </div>

          <div class="ThongTinDonHang">






          </div>

      </div>

    </div>
</html>