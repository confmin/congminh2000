<?php

include("auth.php");
include('Connect.php');
include('header.php');
?>
      <div class="Phan2Phai">
            <div class="container" style="border: 1px solid #343a40;margin-top:20px;border-radius: 5px;background:#ddf1f2">
                <div class="panel panel-primary">
                  <div class="panel-heading">
                    <h3 class="text-center" style="margin-top:15px">Thêm Khách Hàng</h3>
                  </div>
                  <div class="panel-body">
                    <form method="POST" >
                      <div class="form-group">
                        <label >Tên Khách Hàng</label>
                        <input type="number" name="MaKH" style="display: none;">
                        <input required="true" type="text" class="form-control"  name="TenKH">
                      </div>
                      <div class="form-group">
                        <label >Sinh Ngày</label>
                        <input required="true" type="text" id="SinhNgay" class="form-control"  name="SinhNgay">
                      </div>
                      <div class="form-group">
                        <label >Địa Chỉ</label>
                        <input required="true" type="text" id="DiaChi" class="form-control"  name="DiaChi">
                      </div>
                      <div class="form-group">
                        <label> Số Điện Thoại</label>
                        <input required="true" type="text" id="SDT" class="form-control"  name="SDT">
                      </div>
                      <div class="form-group">
                        <label>Tài Khoản</label>
                        <input required="true" type="text" id="TaiKhoan" class="form-control"  name="TaiKhoan">
                      </div>
                      <div class="form-group">
                        <label>Mật Khẩu</label>
                        <input required="true" type="text" id="MatKhau" class="form-control"  name="MatKhau">
                      </div>
                      <button id="button" class="btn btn-success"  style="margin-left: 500px" >Lưu Lại</button>
                    </form>
                  </div>
              </div>

          </div>

          <?php
         
                if(!empty($_POST)){
                  if(isset($_POST['TenKH'])){
                    $TenKH = $_POST['TenKH'];
                  }
                  if(isset($_POST['SinhNgay'])){
                   $SinhNgay = $_POST['SinhNgay'];
                  }
                  if(isset($_POST['DiaChi'])){
                   $DiaChi = $_POST['DiaChi'];
                  }
                  if(isset($_POST['SDT'])){
                    $SDT = $_POST['SDT'];
                  }
                  if(isset($_POST['TaiKhoan'])){
                    $TaiKhoan = $_POST['TaiKhoan'];
                  }
                  if(isset($_POST['MatKhau'])){
                    $MatKhau = $_POST['MatKhau'];
                   
                  }
                  $TenKH = str_replace('\'','\\\'',$TenKH);
                  $SinhNgay = str_replace('\'','\\\'',$SinhNgay);
                  $DiaChi = str_replace('\'','\\\'',$DiaChi);
                  $SDT = str_replace('\'','\\\'',$SDT);
                  $TaiKhoan = str_replace('\'','\\\'',$TaiKhoan);
                  $MatKhau = str_replace('\'','\\\'',$MatKhau);
                  $query = "INSERT INTO khachhang(TenKH,SinhNgay,DiaChi,SDT,TaiKhoan,MatKhau) VALUES ('$TenKH','$SinhNgay','$DiaChi','$SDT','$TaiKhoan','$MatKhau')";
                  $result=mysqli_query($db,$query);
              
                
                }
                ?>
      </div>
    </div>
    