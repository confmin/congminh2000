<?php
include('auth.php');
include('header.php');
?>
<table class="table table-hover" style="margin-top: 30px;border: 1px solid #343a40;width:1200px">
                <thead>
                  <tr class="bg-dark text-white">
                    <th>STT</th>
                    <th>Tên Khách Hàng</th>
                    <th>Ngày Sinh</th>
                    <th>Địa Chỉ</th> 
                    <th>Số Điện Thoại</th>
                    <th>Tài Khoản</th>
                    <th>Mật Khẩu</th>
                    <th>Thay Đổi</th>
                    <th>Xoá Bỏ</th>
                  </tr>
                </thead>
                <tbody>



<?php
        
        if (isset($_REQUEST['submit'])) 
        {
            
            $timkiem = addslashes($_GET['timkiem']);
 
            
            if (empty($timkiem)) {
                echo "Yeu cau nhap du lieu vao o trong";
            } 
            else
            {
               include("Connect.php");
                $query = "SELECT * from khachhang where SDT like '%$timkiem%'";
                $sql = mysqli_query($db,$query);
                $num = mysqli_num_rows($sql);
                if ($num > 0 && $timkiem != "") 
                {
                   
                   
                    while ($row = mysqli_fetch_assoc($sql)) {
                        echo '<tr>
                        <td>'.$row['MaKH'].'</td>
                        <td>'.$row['TenKH'].'</td>
                        <td>'.$row['SinhNgay'].'</td>
                        <td>'.$row['DiaChi'].'</td>
                        <td>'.$row['SDT'].'</td>
                        <td>'.$row['TaiKhoan'].'</td>
                        <td>'.$row['MatKhau'].'</td>
                        <td><button class="btn btn-warning">Edit</button></td>
                        <td><button class="btn btn-warning" >Delete</button></td>
                      </tr>'; 
                  }   
                
                    
                    
                    echo'</tbody>';
                    echo '</table>';
                } 
                else {
                    echo "Khong tim thay ket qua!";
                }
            }
        }
        ?>   