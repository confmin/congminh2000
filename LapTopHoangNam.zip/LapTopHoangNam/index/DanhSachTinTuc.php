<!DOCTYPE html>
<?php
// Start the session
session_start();
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../Image/image1.ico" type="image/x-icon">
    <link rel="icon" href="../Image/image1.ico" type="image/x-icon">
    <link rel="stylesheet" href="../CSS/HomePage.css">
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Danh Sách Tin Tức - LapTop Hoàng Nam</title>
</head>
  <body>
    <div class="Phan1" >
      <div class="Phan1Trai">
        <img src="../Image/image1.ico" alt="">
        <p>LapTop Hoàng Nam</p>
      </div>
      <div class="Phan1Phai">
      <div class="dropdown show">
        <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width: 250px;">
          <img src="../Image/image4.jpg" alt="" class=" img-fluid "> 
          <span style="padding-left: 10px;"> <?php echo $_SESSION['name'];?></span>
        </a>

        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" style="width:100%;margin-left:3px">
        <form action="Login.php" method="get">
              <input type="submit" name="submit" value="Đăng Xuất" class="input5" style="margin-left:80px;">
              <hr>
        </form>
        <form action="Registration.php" method="get">
              <input type="submit" name="submit" value="Đăng Ký Tài Khoản Mới" class="input5" style="margin-left:40px;">
        </form>      
        </div>
      </div>
    </div>

    </div>
    <div class="Phan2">
      <div class="Phan2Trai">
        <ul class="menu1">
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Sản Phẩm</a>
            <ul class="menu2">
              <li><a href="DanhSachSanPham.php">Danh Sách Sản Phẩm</a></li>
              <li><a href="DanhMucSanPham.php">Danh Mục Sản Phẩm</a></li>
            </ul>
          </li>
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Đơn Hàng</a>
            <ul class="menu2">
              <li><a href="QuanLyDonHang.php">Danh Sách Đơn Hàng</a></li>
            </ul>
          </li>
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Khách Hàng</a>
            <ul class="menu2">
              <li><a href="QuanLyKhachHang.php">Danh Sách Khách Hàng</a></li>
            </ul>
          </li>
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Tin Tức</a>
            <ul class="menu2">
              <li><a href="DanhSachTinTuc.php">Danh Sách Tin Tức</a></li>
              <li><a href="DanhMucTinTuc.php">Danh Mục Tin Tức</a></li>
            </ul>
          </li>
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Nhân Viên</a>
            <ul class="menu2">
              <li><a href="QuanLyNhanVien.php">Danh Sách Nhân Viên</a></li>
            </ul>
          </li>
          <li class="QuayLaiTrangChu">
            <a href="HomePage.php" style="font-size: 18px;">Quay Lại Trang Chủ</a>
          </li>
        </ul>
      </div>
      <div class="Phan2Phai">
          

      </div>

    </div>
    
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>