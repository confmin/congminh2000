<?php
    $host = "localhost";
	$user = "root";
	$password = "";
	$database = "laptop";
    $db = mysqli_connect($host,$user,$password,$database);
    if($db->connect_error){
        die("connect failed".$db->connect_error);
        echo "Không thành công";
    }
  
    function executeResult($sql){
        $host = "localhost";
        $user = "root";
        $password = "";
        $database = "laptop";
        $db = mysqli_connect($host,$user,$password,$database);
        $resultset = mysqli_query($db,$sql);
        $list = [];
        while($row = mysqli_fetch_array($resultset ,1)){
            $list[] =$row;
        }
        mysqli_close($db);
        return $list;
    }
