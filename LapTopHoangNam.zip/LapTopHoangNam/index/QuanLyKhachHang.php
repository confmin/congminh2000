<?php
include("auth.php");
include('Connect.php');
include('header.php');
?>
<?php
 

?>

    <div class="Phan2">
      <div class="Phan2Phai">
          <div class="DangNhapThanhCong" style="display: flex;height:45px;width:95%;margin-top:30px;margin-left:20px;">
            <p style="padding-top: 10px;font-size:18px">Danh Sách Khách Hàng</p>
            <div class="col-md-2"><a href="AddKhachHang.php" class="btn btn-danger" role="button" style="margin-left:830px;width:160px;height:45px" >Thêm Khách Hàng</a></div>
          </div>
          <div class="container" style="margin-top: 30px;margin-left:5px;">
              <div class="row">
              <form action="timkiem.php" method="get">
                Search: <input type="text" name="timkiem" />
                <input type="submit" name="submit" value="search" />
            </form>
                 
              </div> 
               </script>         
              <table class="table table-hover" style="margin-top: 30px;border: 1px solid #343a40;width:1200px">
                <thead>
                  <tr class="bg-dark text-white">
                    <th>STT</th>
                    <th>Tên Khách Hàng</th>
                    <th>Ngày Sinh</th>
                    <th>Địa Chỉ</th> 
                    <th>Số Điện Thoại</th>
                    <th>Tài Khoản</th>
                    <th>Mật Khẩu</th>
                    <th>Thay Đổi</th>
                    <th>Xoá Bỏ</th>
                  </tr>
                </thead>
                <tbody >
                <?php 
                 $result = mysqli_query($db, 'SELECT count(ID) as total from khachhang');
                 $row = mysqli_fetch_assoc($result);
                 $total_records = $row['total'];
                 $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
                       $limit = 8;
                       $total_page = ceil($total_records / $limit);
                       if ($current_page > $total_page){
                         $current_page = $total_page;
                     }
                     else if ($current_page < 1){
                         $current_page = 1;
                     }
                     $start = ($current_page - 1) * $limit;
                     $result = mysqli_query($db, "SELECT * FROM khachhang LIMIT $start, $limit");
                     while ($row = mysqli_fetch_assoc($result)){
                      echo '<tr>
                        <td>'.$row['MaKH'].'</td>
                        <td>'.$row['TenKH'].'</td>
                        <td>'.$row['SinhNgay'].'</td>
                        <td>'.$row['DiaChi'].'</td>
                        <td>'.$row['SDT'].'</td>
                        <td>'.$row['TaiKhoan'].'</td>
                        <td>'.$row['MatKhau'].'</td>
                        <td><button class="btn btn-warning">Edit</button></td>
                        <td><button class="btn btn-warning" >Delete</button></td>
                      </tr>'; 
                  }   
                ?>
                </tbody>
              </table>


              <ul class="pagination">
      <?php
          if ($current_page > 1 && $total_page > 1){
            echo '<a href="index.php?page='.($current_page-1).'">Prev</a> | ';
        }
        for ($i = 1; $i <= $total_page; $i++){     
          if ($i == $current_page){
              echo '<span>'.$i.'</span> | ';
          }
          else{
              echo '<a href="index.php?page='.$i.'">'.$i.'</a> | ';
          }
      }
      if ($current_page < $total_page && $total_page > 1){
          echo '<a href="index.php?page='.($current_page+1).'">Next</a> | ';
      }
      ?>
  </ul>
        </div>
      </div>

    </div>