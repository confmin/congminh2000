<?php

session_start();
session_destroy();

?>
<html>
<script type="text/javascript">
            window.location.href = "Login.php"
        </script>
</html>