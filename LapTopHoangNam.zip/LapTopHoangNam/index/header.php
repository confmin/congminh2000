<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../Image/image1.ico" type="image/x-icon">
    <link rel="icon" href="../Image/image1.ico" type="image/x-icon">
    <link rel="stylesheet" href="../CSS/HomePage.css">
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Trang Chủ - LapTop Hoàng Nam</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
  <body>

  <div class="Phan1" >
      <div class="Phan1Trai">
         <a href=HomePage.php>
        <img src="../Image/image1.ico" alt="Trang Chủ">
        </a>
        <p>LapTop Hoàng Nam</p>
       </div>
        <div class="Phan1Phai">
         <div class="dropdown">
           <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
          <?php echo $_SESSION["username"]; ?>
          </button>
             <div class="dropdown-menu">
             <h5 class="dropdown-header">Chức năng</h5>
               <a class="dropdown-item" href="logout.php">Đăng Xuất</a>
               <a class="dropdown-item" href="Registration.php">Đăng ký tài khoản</a>
             <h5 class="dropdown-header">Chức năng khác</h5>
               <a class="dropdown-item" href="#">Kiểm tra</a>
           </div>
      </div>
      </div>
      </div>
  

    </div>
    <div class="Phan2">
      <div class="Phan2Trai">
        <ul class="menu1">
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Sản Phẩm</a>
            <ul class="menu2">
              <li><a href="DanhSachSanPham.php">Danh Sách Sản Phẩm</a></li>
              <li><a href="DanhMucSanPham.php">Danh Mục Sản Phẩm</a></li>
            </ul>
          </li>
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Đơn Hàng</a>
            <ul class="menu2">
              <li><a href="QuanLyDonHang.php">Danh Sách Đơn Hàng</a></li>
            </ul>
          </li>
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Khách Hàng</a>
            <ul class="menu2">
              <li><a href="QuanLyKhachHang.php">Danh Sách Khách Hàng</a></li>
            </ul>
          </li>
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Tin Tức</a>
            <ul class="menu2">
              <li><a href="DanhSachTinTuc.php">Danh Sách Tin Tức</a></li>
              <li><a href="DanhMucTinTuc.php">Danh Mục Tin Tức</a></li>
            </ul>
          </li>
          <li class="li1">
            <a href="" style="font-size: 18px;">Quản Lý Nhân Viên</a>
            <ul class="menu2">
              <li><a href="QuanLyNhanVien.php">Danh Sách Nhân Viên</a></li>
            </ul>
          </li>
          <li class="QuayLaiTrangChu">
            <a href="HomePage.php" style="font-size: 18px;">Quay Lại Trang Chủ</a>
          </li>
        </ul>
</div>
  </body>
</html>